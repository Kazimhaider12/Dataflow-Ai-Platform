"""
main.py
--------
FastAPI app. Endpoints:

  Auth:
    POST /signup           -> naya account banao
    POST /login             -> token milta hai

  Data:
    POST /upload             -> file leta hai (protected), profile return karta hai
    POST /ingest-url         -> URL se CSV/JSON pull karta hai (multiple data source)
    POST /clean              -> AI agent chalata hai, cleaned data + steps return karta hai
    GET  /dashboard/{id}     -> chart-ready aggregates deta hai
    GET  /download/{id}      -> cleaned dataset CSV ki tarah
    GET  /sessions           -> logged-in user ke sab datasets list karta hai

Persistence: SQLite (metadata) + parquet files (actual data) — db.py dekho.
Auth: simple built-in token auth — auth.py dekho.
"""

import io
import uuid
import requests
import pandas as pd
from fastapi import FastAPI, UploadFile, File, HTTPException, Form, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, EmailStr

import db
from data_tools import profile_data, generate_dashboard_data, _format_business_label, _format_metric_value
from ai_agent import run_cleaning_agent, run_derived_columns_agent, generate_ai_insights
from auth import hash_password, verify_password, get_current_user

app = FastAPI(title="Data Automation Platform")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # dev ke liye open, production mein specific domain rakho
    allow_methods=["*"],
    allow_headers=["*"],
)

db.init_db()


# ---------------------------------------------------------------------
# AUTH
# ---------------------------------------------------------------------

class SignupBody(BaseModel):
    email: EmailStr
    password: str


class LoginBody(BaseModel):
    email: EmailStr
    password: str


@app.post("/signup")
async def signup(body: SignupBody):
    if db.get_user_by_email(body.email):
        raise HTTPException(status_code=400, detail="Ye email pehle se registered hai.")
    if len(body.password) < 6:
        raise HTTPException(status_code=400, detail="Password kam se kam 6 characters ka ho.")

    user_id = db.create_user(body.email, hash_password(body.password))
    token = db.create_token(user_id)
    return {"token": token, "user_id": user_id, "email": body.email}


@app.post("/login")
async def login(body: LoginBody):
    user = db.get_user_by_email(body.email)
    if not user or not verify_password(body.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Email ya password galat hai.")

    token = db.create_token(user["id"])
    return {"token": token, "user_id": user["id"], "email": user["email"]}


# ---------------------------------------------------------------------
# DATA INGESTION
# ---------------------------------------------------------------------

def _read_file_to_df(filename: str, raw_bytes: bytes) -> pd.DataFrame:
    if not raw_bytes:
        raise HTTPException(status_code=400, detail="The selected file is empty.")

    filename = (filename or "").lower()
    if filename.endswith(".csv"):
        try:
            return pd.read_csv(io.BytesIO(raw_bytes))
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Unable to read CSV file: {str(e)}") from e
    elif filename.endswith((".xlsx", ".xls")):
        try:
            return pd.read_excel(io.BytesIO(raw_bytes))
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Unable to read Excel file: {str(e)}") from e
    else:
        raise HTTPException(status_code=400, detail="Sirf .csv ya .xlsx files supported hain abhi.")


@app.post("/upload")
async def upload_file(file: UploadFile = File(...), user_id: str = Depends(get_current_user)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Please choose a file to upload.")

    raw_bytes = await file.read()
    df = _read_file_to_df(file.filename, raw_bytes)

    # ---- Data validation (Step 1): empty dataset ko reject karo ----
    if df.shape[0] == 0:
        raise HTTPException(status_code=400, detail="Uploaded file mein koi row nahi hai (empty dataset).")
    if len(df.columns) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file mein koi column detect nahi hua.")

    session_id = str(uuid.uuid4())
    db.save_dataframe(session_id, df, user_id=user_id, filename=file.filename)

    return {"session_id": session_id, "profile": profile_data(df)}


class IngestUrlBody(BaseModel):
    url: str
    format: str = "csv"  # "csv" | "json"


@app.post("/ingest-url")
async def ingest_url(body: IngestUrlBody, user_id: str = Depends(get_current_user)):
    """Doosra data source: koi bhi public CSV/JSON URL se seedha data khinch lo."""
    try:
        resp = requests.get(body.url, timeout=15)
        resp.raise_for_status()
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"URL se data fetch nahi ho saka: {str(e)}")

    try:
        if body.format == "json":
            df = pd.read_json(io.BytesIO(resp.content))
        else:
            df = pd.read_csv(io.BytesIO(resp.content))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Data parse nahi ho saka: {str(e)}")

    if df.shape[0] == 0:
        raise HTTPException(status_code=400, detail="Fetched data mein koi row nahi hai (empty dataset).")
    if len(df.columns) == 0:
        raise HTTPException(status_code=400, detail="Fetched data mein koi column detect nahi hua.")

    session_id = str(uuid.uuid4())
    db.save_dataframe(session_id, df, user_id=user_id, filename=body.url)

    return {"session_id": session_id, "profile": profile_data(df)}


# ---------------------------------------------------------------------
# AI CLEANING
# ---------------------------------------------------------------------

@app.post("/clean")
async def clean_data(
    session_id: str = Form(...),
    instruction: str = Form(""),
    user_id: str = Depends(get_current_user),
):
    if not db.session_exists(session_id):
        raise HTTPException(status_code=404, detail="Session not found. Pehle /upload karo.")

    if not db.check_and_increment_usage(user_id):
        raise HTTPException(
            status_code=429,
            detail=f"Aaj ki free-tier limit ({db.DAILY_FREE_LIMIT} requests) khatam ho gayi. Kal try karo.",
        )

    df = db.load_dataframe(session_id)
    cleaned_df, steps_log, summary = run_cleaning_agent(df, user_instruction=instruction)

    db.save_dataframe(session_id, cleaned_df, user_id=user_id)

    # Convert NaN to None for JSON serialization
    preview = cleaned_df.head(10).where(pd.notna(cleaned_df.head(10)), None).to_dict(orient="records")

    return {
        "session_id": session_id,
        "steps_taken": steps_log,
        "summary": summary,
        "new_profile": profile_data(cleaned_df),
        "preview": preview,
    }


# ---------------------------------------------------------------------
# DASHBOARD / DOWNLOAD / SESSIONS
# ---------------------------------------------------------------------

@app.get("/dashboard/{session_id}")
async def get_dashboard(
    session_id: str,
    filters: str = None,
    user_id: str = Depends(get_current_user),
):
    """
    filters: optional JSON string, e.g. '{"continent":"Asia","year":"2020"}'
    Supports multiple simultaneous slicers.
    """
    if not db.session_exists(session_id):
        raise HTTPException(status_code=404, detail="Session not found.")
    df = db.load_dataframe(session_id)

    filter_dict = None
    if filters:
        try:
            import json as _json
            filter_dict = _json.loads(filters)
        except Exception:
            raise HTTPException(status_code=400, detail="filters query param must be valid JSON.")

    return generate_dashboard_data(df, filters=filter_dict)


@app.get("/ai-dashboard/{session_id}")
async def get_ai_dashboard(
    session_id: str,
    filters: str = None,
    user_id: str = Depends(get_current_user),
):
    """
    Full AI-driven dashboard:
      1. AI dataset ka domain samajhta hai aur missing-but-derivable business
         metrics propose karta hai (e.g. death_rate_pct, profit_margin) —
         AI sirf FORMULA deta hai, Python actual number calculate karta hai.
      2. Real KPIs/charts inhi (original + derived) columns se compute hote
         hain — koi number AI khud nahi likhta, hallucination-proof.
      3. AI in real numbers ko dekh kar genuine business insights,
         recommendations, aur executive summary likhta hai.
    """
    if not db.session_exists(session_id):
        raise HTTPException(status_code=404, detail="Session not found.")

    if not db.check_and_increment_usage(user_id):
        raise HTTPException(
            status_code=429,
            detail=f"Aaj ki free-tier limit ({db.DAILY_FREE_LIMIT} requests) khatam ho gayi. Kal try karo.",
        )

    df = db.load_dataframe(session_id)

    filter_dict = None
    if filters:
        try:
            import json as _json
            filter_dict = _json.loads(filters)
        except Exception:
            raise HTTPException(status_code=400, detail="filters query param must be valid JSON.")

    # Step 1: AI proposes derived columns, computed safely via pandas.eval
    enriched_df, derived_columns = run_derived_columns_agent(df)

    # Step 2: real dashboard numbers from (original + derived) columns
    dashboard = generate_dashboard_data(enriched_df, filters=filter_dict)

    # Derived metrics ko explicitly headline KPI ki tarah surface karo —
    # taake AI ka sochaa hua metric hamesha dikhe, chahe woh column-order
    # mein pehle ho ya nahi.
    for dcol in derived_columns:
        col_name = dcol["name"]
        if col_name not in enriched_df.columns:
            continue
        col_data = enriched_df[col_name].dropna()
        if col_data.empty:
            continue
        avg_val = float(col_data.mean())
        dashboard["kpis"].insert(1, {
            "label": f"{_format_business_label(col_name)} (AI-derived)",
            "value": _format_metric_value(avg_val),
            "icon": "\u2728",
        })

    # Step 3: AI narrative on top of the real, computed numbers
    ai_narrative = generate_ai_insights(dashboard)
    dashboard["insights"] = ai_narrative["insights"]
    dashboard["recommendations"] = ai_narrative["recommendations"]
    dashboard["executive_summary"] = ai_narrative["executive_summary"]
    dashboard["ai_generated"] = ai_narrative["ai_generated"]
    dashboard["derived_columns"] = derived_columns

    # Trust score ko AI-narrative ki success ke saath bhi update karo
    ts = dashboard.get("trust_score", {"data_valid": True, "calculation_correct": True})
    ts["ai_grounded"] = ai_narrative["ai_generated"]
    ts["score"] = sum([ts.get("data_valid", False), ts.get("calculation_correct", False), ts["ai_grounded"]])
    ts["max_score"] = 3
    dashboard["trust_score"] = ts

    return dashboard


@app.get("/download/{session_id}")
async def download_cleaned(session_id: str, user_id: str = Depends(get_current_user)):
    if not db.session_exists(session_id):
        raise HTTPException(status_code=404, detail="Session not found.")

    df = db.load_dataframe(session_id)
    stream = io.StringIO()
    df.to_csv(stream, index=False)
    response = StreamingResponse(iter([stream.getvalue()]), media_type="text/csv")
    response.headers["Content-Disposition"] = "attachment; filename=cleaned_data.csv"
    return response


@app.get("/sessions")
async def get_sessions(user_id: str = Depends(get_current_user)):
    return db.list_sessions(user_id=user_id)


@app.get("/")
async def root():
    return {"status": "running", "message": "Data Automation Platform - use /docs for API playground"}
