"""
db.py
------
Persistent storage layer.

Pehle sara data sirf Python dict (RAM) mein tha — server restart hote hi
sab udd jata tha. Ab:

  - Session METADATA (session_id, filename, created_at, user_id, status)
    SQLite mein store hota hai (data/app.db)
  - Actual DATAFRAME (jo bara ho sakta hai) disk pe parquet file ki
    tarah store hota hai (data/sessions/<session_id>.parquet)

Parquet CSV se better hai kyun ke ye dtypes preserve karta hai
(dates, ints, etc. dobara load karne pe sahi type mein aate hain).
"""

import os
import sqlite3
import uuid
from datetime import datetime, date
import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
SESSIONS_DIR = os.path.join(DATA_DIR, "sessions")
DB_PATH = os.path.join(DATA_DIR, "app.db")

os.makedirs(SESSIONS_DIR, exist_ok=True)


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY,
            user_id TEXT,
            filename TEXT,
            row_count INTEGER,
            col_count INTEGER,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS api_usage (
            user_id TEXT NOT NULL,
            usage_date TEXT NOT NULL,
            request_count INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (user_id, usage_date)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS auth_tokens (
            token TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


# ---------------------------------------------------------------------
# SESSION (dataset) PERSISTENCE
# ---------------------------------------------------------------------

def _storage_path(session_id: str) -> str:
    return os.path.join(SESSIONS_DIR, f"{session_id}.pkl")


def save_dataframe(session_id: str, df: pd.DataFrame, user_id: str = None, filename: str = ""):
    """Naya session banata hai ya existing ko update karta hai (dataframe disk pe, metadata DB mein)."""
    df.to_pickle(_storage_path(session_id))

    conn = get_conn()
    cur = conn.cursor()
    now = datetime.utcnow().isoformat()

    existing = cur.execute("SELECT id FROM sessions WHERE id = ?", (session_id,)).fetchone()
    if existing:
        cur.execute(
            "UPDATE sessions SET row_count=?, col_count=?, updated_at=? WHERE id=?",
            (len(df), len(df.columns), now, session_id),
        )
    else:
        cur.execute(
            "INSERT INTO sessions (id, user_id, filename, row_count, col_count, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (session_id, user_id, filename, len(df), len(df.columns), now, now),
        )
    conn.commit()
    conn.close()


def load_dataframe(session_id: str) -> pd.DataFrame:
    path = _storage_path(session_id)
    if not os.path.exists(path):
        return None
    return pd.read_pickle(path)


def session_exists(session_id: str) -> bool:
    return os.path.exists(_storage_path(session_id))


def list_sessions(user_id: str = None):
    conn = get_conn()
    cur = conn.cursor()
    if user_id:
        rows = cur.execute(
            "SELECT * FROM sessions WHERE user_id = ? ORDER BY updated_at DESC", (user_id,)
        ).fetchall()
    else:
        rows = cur.execute("SELECT * FROM sessions ORDER BY updated_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------
# USERS (simple built-in auth — no external service needed)
# ---------------------------------------------------------------------

def create_user(email: str, password_hash: str) -> str:
    user_id = str(uuid.uuid4())
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO users (id, email, password_hash, created_at) VALUES (?, ?, ?, ?)",
        (user_id, email, password_hash, datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()
    return user_id


def get_user_by_email(email: str):
    conn = get_conn()
    cur = conn.cursor()
    row = cur.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    conn.close()
    return dict(row) if row else None


def create_token(user_id: str) -> str:
    import secrets
    token = secrets.token_hex(32)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO auth_tokens (token, user_id, created_at) VALUES (?, ?, ?)",
        (token, user_id, datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()
    return token


def get_user_id_by_token(token: str):
    conn = get_conn()
    cur = conn.cursor()
    row = cur.execute("SELECT user_id FROM auth_tokens WHERE token = ?", (token,)).fetchone()
    conn.close()
    return row["user_id"] if row else None


def delete_token(token: str):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM auth_tokens WHERE token = ?", (token,))
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------
# DAILY FREE-TIER USAGE LIMIT
# ---------------------------------------------------------------------

DAILY_FREE_LIMIT = 20  # free tier: 20 /clean calls per day per user


def check_and_increment_usage(user_id: str) -> bool:
    """
    True return karta hai agar user apni daily limit ke andar hai (aur count
    ko +1 kar deta hai). False agar limit khatam ho chuki hai.
    """
    today = date.today().isoformat()
    conn = get_conn()
    cur = conn.cursor()

    row = cur.execute(
        "SELECT request_count FROM api_usage WHERE user_id=? AND usage_date=?",
        (user_id, today),
    ).fetchone()

    if row is None:
        cur.execute(
            "INSERT INTO api_usage (user_id, usage_date, request_count) VALUES (?, ?, 1)",
            (user_id, today),
        )
        conn.commit()
        conn.close()
        return True

    current_count = row["request_count"]
    if current_count >= DAILY_FREE_LIMIT:
        conn.close()
        return False

    cur.execute(
        "UPDATE api_usage SET request_count = request_count + 1 WHERE user_id=? AND usage_date=?",
        (user_id, today),
    )
    conn.commit()
    conn.close()
    return True
