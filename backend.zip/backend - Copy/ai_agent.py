"""
ai_agent.py
------------
Ye "brain" hai. User ka data profile aur instruction leta hai, LLM ko
deta hai tool-schemas ke saath, aur LLM jo bhi tools chalane ko kahe
unhe data_tools.py se execute karta hai — turn by turn — jab tak model
"done" na keh de.

Ye hi wo agentic loop hai jo pura ETL pipeline khud decide karta hai.

Provider configurable hai via AI_PROVIDER env var (.env mein):
  AI_PROVIDER=groq    -> Groq cloud API (free tier, internet chahiye)
  AI_PROVIDER=ollama  -> Local Ollama (offline, apna hardware use hota hai)

Groq key yahan se lo: https://console.groq.com/keys
Ollama setup: https://ollama.com -> `ollama pull llama3.2` -> `ollama serve`
"""

import os
import json
import re
import pandas as pd
from dotenv import load_dotenv
from data_tools import TOOL_REGISTRY, TOOL_SCHEMAS, profile_data

load_dotenv()

try:
    from openai import OpenAI
except ImportError:  # pragma: no cover - defensive fallback for local/dev environments
    OpenAI = None

AI_PROVIDER = os.environ.get("AI_PROVIDER", "groq").strip().lower()

client = None
MODEL_NAME = None

if AI_PROVIDER == "ollama":
    # Local Ollama — koi API key nahi chahiye, koi internet nahi chahiye.
    # `ollama serve` chalu hona chahiye (default: http://localhost:11434).
    OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1")
    MODEL_NAME = os.environ.get("OLLAMA_MODEL", "llama3.2")
    if OpenAI is not None:
        client = OpenAI(api_key="ollama", base_url=OLLAMA_BASE_URL)  # api_key ignore hoti hai Ollama mein

else:
    # Groq cloud (default) — free tier, internet chahiye.
    GROQ_API_KEY = os.environ.get("GROQ_API_KEY") or os.environ.get("OPENAI_API_KEY")
    MODEL_NAME = os.environ.get("GROQ_MODEL", "openai/gpt-oss-120b")
    # NOTE: llama-3.3-70b-versatile was deprecated by Groq on June 17, 2026.
    # openai/gpt-oss-120b is Groq's recommended replacement with tool-calling support.
    if GROQ_API_KEY and OpenAI is not None:
        client = OpenAI(api_key=GROQ_API_KEY, base_url="https://api.groq.com/openai/v1")


def _to_openai_tools(anthropic_style_schemas: list) -> list:
    """Anthropic-style tool schema ko OpenAI/Groq ke function-calling format mein convert karta hai."""
    converted = []
    for schema in anthropic_style_schemas:
        converted.append({
            "type": "function",
            "function": {
                "name": schema["name"],
                "description": schema["description"],
                "parameters": schema["input_schema"],
            },
        })
    return converted


OPENAI_TOOLS = _to_openai_tools(TOOL_SCHEMAS)

SYSTEM_PROMPT = """Tum ek expert Data Engineer AI ho. Tumhe ek dataset ka profile
(columns, types, missing values, duplicates) aur user ki instruction di jayegi.

Tumhara kaam hai available tools ko step-by-step call karke dataset ko clean,
structured aur analysis-ready banana.

Rules:
- Har tool call ke baad tumhe naya updated profile milega — usay dekh kar decide karo
  agla step kya hona chahiye.
- Sirf wahi steps lo jo genuinely zaroori hain, unnecessary tool calls mat karo.
- Jab dataset clean/ready lage, ek final text message do jisme summary ho
  ke tumne kya-kya kiya aur kyun. Is final message mein koi tool call na ho.
- Agar user ne specific instruction di hai (e.g. "sirf missing values fix karo"),
  usi scope mein raho.
"""


def _run_basic_cleaning(df: pd.DataFrame, initial_profile: dict, user_instruction: str = "", error_msg: str = ""):
    """
    Fallback cleaning jab LLM available nahi hota.
    Basic steps: duplicates drop karo, numeric columns mein missing values fill karo.
    """
    steps_log = []
    current_df = df.copy()
    
    # Step 1: Remove duplicates
    dup_count = current_df.duplicated().sum()
    if dup_count > 0:
        current_df = current_df.drop_duplicates().reset_index(drop=True)
        steps_log.append({"tool": "drop_duplicates", "args": {}})
    
    # Step 2: Fill missing values in numeric columns
    for col in current_df.columns:
        if pd.api.types.is_numeric_dtype(current_df[col]):
            missing_count = current_df[col].isna().sum()
            if missing_count > 0:
                # Use median for numeric columns
                current_df[col] = current_df[col].fillna(current_df[col].median())
                steps_log.append({"tool": "fill_missing", "args": {"column": col, "strategy": "median"}})
        else:
            missing_count = current_df[col].isna().sum()
            if missing_count > 0:
                # Use mode or empty string for string columns
                current_df[col] = current_df[col].fillna("")
                steps_log.append({"tool": "fill_missing", "args": {"column": col, "strategy": "mode"}})
    
    # Summary
    error_note = f"\n(LLM unavailable: {error_msg})" if error_msg else ""
    final_summary = f"""Data cleaning complete (basic mode - LLM not configured).

Steps taken:
- Removed {dup_count} duplicate rows
- Filled missing values in {len(steps_log) - (1 if dup_count > 0 else 0)} columns

Dataset is now ready for analysis. {user_instruction if user_instruction else ''}{error_note}"""
    
    return current_df, steps_log, final_summary



def run_cleaning_agent(df: pd.DataFrame, user_instruction: str = "", max_turns: int = 8):
    """
    LLM (Groq/Llama) ke saath ek agentic loop chalata hai jo dataset ko clean karta hai.
    Returns: (cleaned_df, steps_log, final_summary)
    
    Agar API key nahi hai, fallback basic cleaning use hota hai.
    """
    steps_log = []
    current_df = df.copy()

    initial_profile = profile_data(current_df)
    
    # Fallback: agar LLM client available nahi hai, basic cleaning karo
    if client is None:
        return _run_basic_cleaning(current_df, initial_profile, user_instruction)
    
    user_msg = (
        f"Dataset profile:\n{json.dumps(initial_profile, indent=2)}\n\n"
        f"User instruction: {user_instruction or 'Dataset ko general best-practices ke mutabiq clean karo.'}"
    )

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_msg},
    ]
    final_summary = ""

    try:
        for turn in range(max_turns):
            response = client.chat.completions.create(
                model=MODEL_NAME,
                max_tokens=1500,
                tools=OPENAI_TOOLS,
                messages=messages,
            )

            msg = response.choices[0].message
            messages.append(msg.model_dump(exclude_none=True))

            tool_calls = msg.tool_calls or []

            if not tool_calls:
                # Model ne koi tool nahi call kiya -> final answer de raha hai
                final_summary = msg.content or ""
                break

            for call in tool_calls:
                fn_name = call.function.name
                try:
                    fn_args = json.loads(call.function.arguments)
                except json.JSONDecodeError:
                    fn_args = {}
                fn = TOOL_REGISTRY.get(fn_name)

                if fn is None:
                    result_text = f"Error: unknown tool {fn_name}"
                else:
                    try:
                        current_df = fn(current_df, **fn_args)
                        steps_log.append({"tool": fn_name, "args": fn_args})
                        new_profile = profile_data(current_df)
                        result_text = json.dumps(new_profile)
                    except Exception as e:
                        result_text = f"Error running {fn_name}: {str(e)}"

                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": result_text,
                })

        return current_df, steps_log, final_summary
    
    except Exception as e:
        # LLM failed - fall back to basic cleaning
        return _run_basic_cleaning(current_df, initial_profile, user_instruction, error_msg=str(e))


# ---------------------------------------------------------------------
# AI BUSINESS INSIGHTS (dashboard ke liye — Senior Data Analyst persona)
# ---------------------------------------------------------------------

INSIGHTS_SYSTEM_PROMPT = """Tum ek Senior Business Data Analyst aur Dashboard Designer ho.
Tumhe ek dataset ka business scorecard (KPIs), chart summaries, aur "verified_facts"
diye jayenge (raw data nahi — sirf aggregated numbers). "verified_facts" wo numbers
hain jo Python ne already calculate kar liye hain — ye 100% sahi hain, in par bharosa
karo aur apne insights inhi facts pe base karo, khud se koi naya number ya category
mat invent karo.

Tumhara kaam hai in numbers se genuine business insights nikalna, na ke sirf numbers
ko wapas sentence mein daalna.

Tumhara mindset: CEO + Analyst + Dashboard Designer, ek saath.

Tumhe SIRF valid JSON return karna hai, bilkul is shape mein, koi extra
text/markdown/backticks nahi:

{
  "insights": ["...", "...", "..."],
  "recommendations": ["...", "...", "..."],
  "executive_summary": "..."
}

Rules:
- "verified_facts" mein diye gaye numbers/categories ko exactly wahi rakho jaise
  diye gaye hain — mat round karo differently, mat naya top-category guess karo.
- "insights": 3-4 bullet points — trends, risks, opportunities jo numbers se
  genuinely nikalte hain (e.g. concentration risk, imbalance, outlier segment,
  growth/decline pattern). Generic statements mat likho jaise "average is X" —
  batao ke ye number KYUN important hai business ke liye.
- "recommendations": 3-4 actionable, specific recommendations jo decision-makers
  use kar sakein — concrete next steps, na ke generic advice.
- "executive_summary": 2-3 sentences, recruiter/executive-friendly tone, jo
  poore dataset ki business story summarize kare.
- Numbers cite karte waqt short-scale format use karo (K/M/B) jo tumhe diya
  gaya hai, apne se recalculate mat karo.
- Business-oriented, confident, concise tone rakho.
"""


# ---------------------------------------------------------------------
# AI DERIVED COLUMNS (dataset dekh kar missing-but-derivable metrics banata hai)
# ---------------------------------------------------------------------

DERIVED_COLUMN_TOOL_SCHEMA = [
    {
        "name": "propose_derived_column",
        "description": (
            "Ek naya business metric column banao jo dataset mein directly nahi hai "
            "lekin existing numeric columns se calculate ho sakta hai (e.g. ratio, "
            "rate, difference, percentage). Sirf tab call karo jab metric genuinely "
            "important ho is dataset ke business domain ke liye."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Naye column ka short snake_case naam, e.g. 'death_rate_pct'.",
                },
                "formula": {
                    "type": "string",
                    "description": (
                        "Pandas df.eval()-compatible arithmetic expression, SIRF existing "
                        "column names, numbers, aur +,-,*,/,() use karo. Koi function call "
                        "ya python code nahi. Example: 'total_deaths / total_cases * 100'"
                    ),
                },
                "reasoning": {
                    "type": "string",
                    "description": "1 line mein batao ye metric business ke liye kyun important hai.",
                },
            },
            "required": ["name", "formula", "reasoning"],
        },
    }
]

DERIVED_COLUMN_SYSTEM_PROMPT = """Tum ek world-class Business Data Analyst ho jo har tarah
ka data dekh chuka hai (sales, health, finance, HR, supply chain, past aur present sab).

Tumhe ek dataset ka schema (columns, types, stats) aur kuch sample rows diye jayenge.

Tumhara kaam:
1. Dataset ka business domain samjho (ye sales data hai? health data? finance? HR?).
2. Socho: is domain mein KAUNSA important metric hota hai jo is dataset mein
   DIRECTLY column ki tarah maujood NAHI hai, lekin do ya zyada existing numeric
   columns ko combine karke calculate ho sakta hai (ratio, rate %, difference,
   per-unit value, etc).
3. Agar aisa koi genuinely useful metric mile, `propose_derived_column` tool
   call karo. Maximum 3 columns propose karo — sirf wahi jo real business value
   dete hain, random combinations mat banao.
4. Agar koi naya derived column zaroori nahi lagta (dataset already complete
   hai), koi tool call mat karo — sirf ek chhota text reply do.

Rules:
- Formula SIRF existing column names, numbers, +,-,*,/,() use kare — kuch
  aur nahi (no function calls, no python syntax).
- Column names bilkul waisi hi likho jaisi tumhe di gayi hain (case-sensitive).
"""


def run_derived_columns_agent(df: pd.DataFrame, max_turns: int = 4):
    """
    AI dataset ka domain samajh kar missing-but-derivable business metrics
    propose karta hai (e.g. profit_margin, death_rate, conversion_rate).
    Har proposal ko pandas df.eval() se safely compute karke naye column
    ki tarah add karta hai — AI sirf FORMULA batata hai, actual number Python
    calculate karta hai (taake AI kabhi galat number na de).

    Returns: (enriched_df, derived_columns_log)
    """
    if client is None:
        return df, []

    working_df = df.copy()
    derived_columns = []

    profile = profile_data(working_df)
    sample = working_df.head(5).where(pd.notna(working_df.head(5)), None).to_dict(orient="records")

    user_msg = (
        f"Dataset profile:\n{json.dumps(profile, indent=2)}\n\n"
        f"Sample rows:\n{json.dumps(sample, indent=2, default=str)}"
    )

    messages = [
        {"role": "system", "content": DERIVED_COLUMN_SYSTEM_PROMPT},
        {"role": "user", "content": user_msg},
    ]

    tools = _to_openai_tools(DERIVED_COLUMN_TOOL_SCHEMA)

    try:
        for _turn in range(max_turns):
            response = client.chat.completions.create(
                model=MODEL_NAME,
                max_tokens=800,
                tools=tools,
                messages=messages,
            )
            msg = response.choices[0].message
            messages.append(msg.model_dump(exclude_none=True))

            tool_calls = msg.tool_calls or []
            if not tool_calls:
                break

            for call in tool_calls:
                try:
                    args = json.loads(call.function.arguments)
                except json.JSONDecodeError:
                    args = {}

                raw_name = str(args.get("name", "")).strip()
                formula = str(args.get("formula", "")).strip()
                reasoning = str(args.get("reasoning", "")).strip()

                safe_name = re.sub(r"[^A-Za-z0-9_]", "_", raw_name).strip("_") or "derived_metric"
                # Naam clash na ho existing column se
                if safe_name in working_df.columns:
                    safe_name = f"{safe_name}_derived"

                result_text = ""
                try:
                    if len(derived_columns) >= 3:
                        result_text = "Limit reached: max 3 derived columns already created."
                    else:
                        computed = working_df.eval(formula)
                        working_df[safe_name] = computed
                        derived_columns.append({
                            "name": safe_name,
                            "formula": formula,
                            "reasoning": reasoning,
                        })
                        result_text = f"Column '{safe_name}' created successfully from formula: {formula}"
                except Exception as e:
                    result_text = f"Error: could not compute formula '{formula}': {str(e)}"

                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": result_text,
                })

        return working_df, derived_columns

    except Exception:
        # LLM call fail hui -> original df hi wapas, koi derived columns nahi
        return df, []


def generate_ai_insights(dashboard_summary: dict) -> dict:
    """
    Dashboard ke KPIs + charts (already computed, aggregated data) AI ko deta
    hai aur real business insights/recommendations/executive summary generate
    karwata hai — rule-based templates ki jagah.

    Returns: {"insights": [...], "recommendations": [...], "executive_summary": "...", "ai_generated": bool}
    """
    fallback = {
        "insights": dashboard_summary.get("insights", []),
        "recommendations": dashboard_summary.get("recommendations", []),
        "executive_summary": "",
        "ai_generated": False,
    }

    if client is None:
        return fallback

    payload = {
        "kpis": dashboard_summary.get("kpis", []),
        "charts": [
            {"title": c.get("column"), "type": c.get("type"), "labels": c.get("labels"), "values": c.get("values")}
            for c in dashboard_summary.get("charts", [])
        ],
        "summary_stats": dashboard_summary.get("summary", {}),
        "verified_facts": dashboard_summary.get("verified_facts", {}),
    }

    try:
        response = client.chat.completions.create(
            model=MODEL_NAME,
            max_tokens=800,
            messages=[
                {"role": "system", "content": INSIGHTS_SYSTEM_PROMPT},
                {"role": "user", "content": f"Dashboard data:\n{json.dumps(payload, indent=2)}"},
            ],
        )
        raw_text = response.choices[0].message.content or ""
        cleaned = raw_text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        parsed = json.loads(cleaned)

        return {
            "insights": parsed.get("insights") or fallback["insights"],
            "recommendations": parsed.get("recommendations") or fallback["recommendations"],
            "executive_summary": parsed.get("executive_summary", ""),
            "ai_generated": True,
        }
    except Exception:
        return fallback
