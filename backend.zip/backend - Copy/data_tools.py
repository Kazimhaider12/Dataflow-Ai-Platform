"""
data_tools.py
--------------
Ye file har wo "tool" define karti hai jo AI agent data pe chala sakta hai.
Har function ek chhota, clear kaam karta hai (single responsibility) taake
AI in ko combine karke koi bhi cleaning/transformation pipeline bana sake.

Naya tool add karna ho to bas ek naya function likho aur TOOL_REGISTRY
aur TOOL_SCHEMAS mein register kar do.
"""

import pandas as pd
import numpy as np
import json
import re


# ---------------------------------------------------------------------
# 1. SCHEMA / PROFILING
# ---------------------------------------------------------------------

def profile_data(df: pd.DataFrame) -> dict:
    """Data ka overview deta hai: columns, types, missing values, duplicates."""
    profile = {
        "num_rows": len(df),
        "num_columns": len(df.columns),
        "columns": [],
        "duplicate_rows": int(df.duplicated().sum()),
    }
    for col in df.columns:
        col_data = df[col]
        col_info = {
            "name": col,
            "dtype": str(col_data.dtype),
            "missing_count": int(col_data.isna().sum()),
            "missing_pct": round(float(col_data.isna().mean() * 100), 2),
            "unique_values": int(col_data.nunique()),
        }
        if pd.api.types.is_numeric_dtype(col_data):
            min_val = float(col_data.min()) if not col_data.empty else None
            max_val = float(col_data.max()) if not col_data.empty else None
            mean_val = float(col_data.mean()) if not col_data.empty else None
            # Convert NaN to None for JSON serialization
            col_info["min"] = None if pd.isna(min_val) else min_val
            col_info["max"] = None if pd.isna(max_val) else max_val
            col_info["mean"] = None if pd.isna(mean_val) else mean_val
        else:
            sample_vals = col_data.dropna().unique()[:5]
            col_info["sample_values"] = [str(v) for v in sample_vals]
        profile["columns"].append(col_info)
    return profile


# ---------------------------------------------------------------------
# 2. CLEANING TOOLS
# ---------------------------------------------------------------------

def drop_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    return df.drop_duplicates().reset_index(drop=True)


def fill_missing(df: pd.DataFrame, column: str, strategy: str = "mean") -> pd.DataFrame:
    """strategy: 'mean' | 'median' | 'mode' | 'zero' | 'drop_rows'"""
    df = df.copy()
    if column not in df.columns:
        return df

    if strategy == "drop_rows":
        return df.dropna(subset=[column])

    if pd.api.types.is_numeric_dtype(df[column]):
        if strategy == "mean":
            df[column] = df[column].fillna(df[column].mean())
        elif strategy == "median":
            df[column] = df[column].fillna(df[column].median())
        elif strategy == "zero":
            df[column] = df[column].fillna(0)
        else:
            df[column] = df[column].fillna(df[column].mode().iloc[0] if not df[column].mode().empty else 0)
    else:
        if strategy == "mode":
            mode_val = df[column].mode()
            df[column] = df[column].fillna(mode_val.iloc[0] if not mode_val.empty else "")
        else:
            df[column] = df[column].fillna("")
    return df


def convert_dtype(df: pd.DataFrame, column: str, target_type: str) -> pd.DataFrame:
    """target_type: 'int' | 'float' | 'str' | 'datetime' | 'category'"""
    df = df.copy()
    if column not in df.columns:
        return df
    try:
        if target_type == "int":
            df[column] = pd.to_numeric(df[column], errors="coerce").astype("Int64")
        elif target_type == "float":
            df[column] = pd.to_numeric(df[column], errors="coerce")
        elif target_type == "str":
            df[column] = df[column].astype(str)
        elif target_type == "datetime":
            df[column] = pd.to_datetime(df[column], errors="coerce")
        elif target_type == "category":
            df[column] = df[column].astype("category")
    except Exception:
        pass
    return df


def strip_whitespace_and_normalize_case(df: pd.DataFrame, column: str, case: str = "lower") -> pd.DataFrame:
    """case: 'lower' | 'upper' | 'title' | 'none'"""
    df = df.copy()
    if column not in df.columns:
        return df
    df[column] = df[column].astype(str).str.strip()
    if case == "lower":
        df[column] = df[column].str.lower()
    elif case == "upper":
        df[column] = df[column].str.upper()
    elif case == "title":
        df[column] = df[column].str.title()
    return df


def remove_outliers_iqr(df: pd.DataFrame, column: str) -> pd.DataFrame:
    """IQR method se numeric column ke outliers remove karta hai."""
    df = df.copy()
    if column not in df.columns or not pd.api.types.is_numeric_dtype(df[column]):
        return df
    q1 = df[column].quantile(0.25)
    q3 = df[column].quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    return df[(df[column] >= lower) & (df[column] <= upper)].reset_index(drop=True)


def rename_columns(df: pd.DataFrame, mapping: dict) -> pd.DataFrame:
    return df.rename(columns=mapping)


def drop_columns(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    return df.drop(columns=[c for c in columns if c in df.columns])


def _format_business_label(name: str) -> str:
    """Column names ko business-friendly, executive-style labels mein convert karta hai."""
    if not name:
        return ""
    clean_name = re.sub(r"[_-]+", " ", str(name)).strip()
    words = clean_name.split()
    if not words:
        return ""

    formatted = []
    for word in words:
        lower = word.lower()
        if lower in {"pct", "percent", "percentage"}:
            formatted.append("%")
        elif lower in {"and", "or", "of", "for", "by", "to", "in", "the"}:
            formatted.append(lower)
        elif lower in {"gpa", "id", "kpi", "api", "ui", "hr", "erp", "csv"}:
            formatted.append(lower.upper())
        else:
            formatted.append(word.title())

    label = " ".join(formatted)
    # "Case Fatality Rate %" jaisa banana hai, "Case Fatality Rate  %" nahi (extra space fix)
    label = re.sub(r"\s+%", " %", label)
    return label


def _format_metric_value(value: float, currency: str = None) -> str:
    """Large numeric values ko business-friendly format mein convert karta hai: 25K, 4.2M, 1.1B."""
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "N/A"

    abs_value = abs(float(value))
    if currency is None:
        currency = ""

    if abs_value >= 1_000_000_000:
        return f"{currency}{value / 1_000_000_000:.1f}B"
    if abs_value >= 1_000_000:
        return f"{currency}{value / 1_000_000:.1f}M"
    if abs_value >= 1_000:
        return f"{currency}{value / 1_000:.0f}K"

    if abs_value >= 100:
        return f"{currency}{value:,.0f}"
    if abs_value >= 10:
        return f"{currency}{value:,.1f}"
    return f"{currency}{value:,.2f}"


def _detect_currency_column(col_name: str, series: pd.Series) -> str:
    """Agar column name ya values business currency se related lag rahi hain to currency symbol return kar de."""
    name = str(col_name).lower()
    if any(token in name for token in ["price", "cost", "revenue", "sales", "income", "amount", "value", "expense", "budget"]):
        return "$"
    return ""


def _try_detect_date_column(col_data: pd.Series) -> bool:
    """Object column string dates ho sakti hain (e.g. '2020-01-22') — detect karta hai."""
    if col_data.empty:
        return False
    sample = col_data.dropna().head(20)
    if sample.empty:
        return False
    try:
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            parsed = pd.to_datetime(sample, errors="coerce")
        return parsed.notna().mean() > 0.8
    except Exception:
        return False


def generate_dashboard_data(df: pd.DataFrame, max_categories: int = 15, filters: dict = None) -> dict:
    """
    Business-style dashboard data generate karta hai:
    - scorecard KPIs with clear business naming
    - executive insights and recommendations
    - chart-ready aggregates for the frontend
    """
    # Keep a reference to the UNFILTERED data so slicer dropdown options
    # don't shrink to just the currently selected value after filtering.
    full_df = df

    # ---- Apply filters (this is what powers the "slicer") ----
    if filters:
        for col, val in filters.items():
            if col in df.columns and val not in (None, "", "__all__"):
                df = df[df[col].astype(str) == str(val)]

    charts = []
    kpis = []
    insights = []
    recommendations = []
    chart_count = 0

    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    object_cols = df.select_dtypes(include=["object"]).columns.tolist()
    datetime_cols = df.select_dtypes(include=["datetime64"]).columns.tolist()

    # Object columns split into: low-cardinality CATEGORY columns (usable for
    # grouping/slicing) vs string-dates vs high-cardinality free text (ignored).
    category_cols = []
    date_like_cols = []
    for col in object_cols:
        col_data = df[col].dropna()
        if col_data.empty:
            continue
        if _try_detect_date_column(col_data):
            date_like_cols.append(col)
        elif col_data.nunique() <= max_categories:
            category_cols.append(col)

    # ---- KPIs ----
    kpis.append({"label": "Total Records", "value": f"{len(df):,}", "icon": "📊"})

    for col in numeric_cols:
        col_data = df[col].dropna()
        if col_data.empty:
            continue
        total = col_data.sum()
        avg = col_data.mean()
        minimum = col_data.min()
        maximum = col_data.max()
        label = _format_business_label(col)
        currency = _detect_currency_column(col, col_data)

        kpis.append({"label": f"Total {label}", "value": _format_metric_value(total, currency), "icon": "🔢"})
        kpis.append({"label": f"Average {label}", "value": _format_metric_value(avg, currency), "icon": "📈"})
        kpis.append({"label": f"Max {label}", "value": _format_metric_value(maximum, currency), "icon": "🏁"})
        kpis.append({"label": f"Min {label}", "value": _format_metric_value(minimum, currency), "icon": "📉"})

        if len(col_data) >= 2:
            first = col_data.iloc[0] if len(col_data) > 0 else np.nan
            last = col_data.iloc[-1] if len(col_data) > 0 else np.nan
            if pd.notna(first) and pd.notna(last) and first != 0:
                growth_pct = ((last - first) / abs(first)) * 100 if first != 0 else 0
                kpis.append({"label": f"Growth in {label}", "value": f"{growth_pct:+.1f}%", "icon": "🚀"})
        break

    # ---- Ratio KPI: relationship between the two leading numeric metrics ----
    if len(numeric_cols) >= 2:
        col_a, col_b = numeric_cols[0], numeric_cols[1]
        sum_a = df[col_a].dropna().sum()
        sum_b = df[col_b].dropna().sum()
        if sum_b not in (0, None) and pd.notna(sum_b):
            ratio = sum_a / sum_b
            label_a = _format_business_label(col_a)
            label_b = _format_business_label(col_b)
            kpis.append({
                "label": f"{label_a} to {label_b} Ratio",
                "value": f"{ratio:.2f}",
                "icon": "⚖️",
            })

    total_cells = len(df) * len(df.columns) if len(df.columns) else 0
    missing_cells = int(df.isna().sum().sum())
    completeness = round(100 - (missing_cells / total_cells * 100), 1) if total_cells else 100.0
    kpis.append({"label": "Data Completeness", "value": f"{completeness}%", "icon": "✅"})

    # ---- Business Insights ----
    if numeric_cols:
        primary_col = numeric_cols[0]
        primary_series = df[primary_col].dropna()
        if not primary_series.empty:
            avg_val = float(primary_series.mean())
            max_val = float(primary_series.max())
            min_val = float(primary_series.min())
            primary_label = _format_business_label(primary_col)
            insights.append(f"The average {primary_label.lower()} is {avg_val:.2f}, which reflects the current performance baseline.")
            insights.append(f"The spread between the best and weakest {primary_label.lower()} values is {max_val - min_val:.2f}, highlighting material variability.")

    if category_cols:
        top_group = None
        top_value = None
        for cat_col in category_cols:
            try:
                grouped = df.groupby(cat_col)[numeric_cols[0]].mean().sort_values(ascending=False)
                if not grouped.empty:
                    top_group = grouped.index[0]
                    top_value = float(grouped.iloc[0])
                    break
            except Exception:
                continue
        if top_group is not None:
            insights.append(f"{top_group} is the strongest segment for {primary_label.lower()} performance and should be used as the benchmark group.")

    if not insights:
        insights.append("The dataset shows a stable base of records with enough structure for business monitoring.")

    # ---- Recommendations ----
    if numeric_cols:
        primary_col = numeric_cols[0]
        low_values = df[df[primary_col] == df[primary_col].min()][[col for col in df.columns if col != primary_col]]
        if not low_values.empty:
            recommendations.append(f"Focus management attention on low-performing records in {_format_business_label(primary_col).lower()} to improve overall outcomes.")
        recommendations.append("Use the top-performing segments as a benchmark for scaling best practices across the business.")

    if category_cols:
        recommendations.append("Prioritize resource allocation toward the strongest business segments and investigate weaker categories for improvement.")

    if not recommendations:
        recommendations.append("Monitor this metric regularly and compare it against targets to guide decision-making.")

    # ---- Charts: smart type selection (best-fit visual per data shape) ----
    MAX_CHARTS = 16
    all_date_cols = datetime_cols + date_like_cols

    # 1) CLUSTERED/GROUPED BAR — agar ek category ke sath 2+ numeric metrics hain,
    #    to unhe ALAG bar charts na banao, EK grouped chart mein combine karo.
    for cat_col in category_cols:
        if chart_count >= MAX_CHARTS:
            break
        try:
            if len(numeric_cols) >= 2:
                metrics = numeric_cols[:4]  # readability ke liye max 4 metrics/cluster
                grouped = df.groupby(cat_col)[metrics].sum()
                grouped = grouped.loc[grouped.sum(axis=1).sort_values(ascending=False).index]
                if len(grouped) >= 2:
                    series = [{"name": _format_business_label(c), "values": [float(v) for v in grouped[c]]} for c in metrics]
                    charts.append({
                        "column": f"{_format_business_label(cat_col)} — Metric Comparison",
                        "type": "clustered_bar",
                        "labels": [str(i) for i in grouped.index],
                        "series": series,
                        "x_label": _format_business_label(cat_col),
                        "y_label": "Value",
                    })
                    chart_count += 1
            elif numeric_cols:
                grouped = df.groupby(cat_col)[numeric_cols[0]].sum().sort_values(ascending=False)
                if len(grouped) >= 2:
                    charts.append({
                        "column": f"{_format_business_label(numeric_cols[0])} by {_format_business_label(cat_col)}",
                        "type": "bar",
                        "labels": [str(v) for v in grouped.index],
                        "values": [float(v) for v in grouped.values],
                        "x_label": _format_business_label(cat_col),
                        "y_label": _format_business_label(numeric_cols[0]),
                    })
                    chart_count += 1
            else:
                counts = df[cat_col].value_counts()
                charts.append({
                    "column": f"Row Count by {_format_business_label(cat_col)}",
                    "type": "bar",
                    "labels": [str(v) for v in counts.index],
                    "values": counts.values.tolist(),
                    "x_label": _format_business_label(cat_col),
                    "y_label": "Row Count",
                })
                chart_count += 1
        except Exception:
            pass

    # 2) STACKED BAR + 100% STACKED BAR — jab 2 categorical dimensions maujood hon
    if len(category_cols) >= 2 and numeric_cols and chart_count < MAX_CHARTS:
        cat1, cat2 = category_cols[0], category_cols[1]
        try:
            pivot = df.pivot_table(index=cat1, columns=cat2, values=numeric_cols[0], aggfunc="sum", fill_value=0)
            if pivot.shape[1] > 6:
                top_cols = pivot.sum().sort_values(ascending=False).head(6).index
                pivot = pivot[top_cols]
            if pivot.shape[0] > 8:
                top_rows = pivot.sum(axis=1).sort_values(ascending=False).head(8).index
                pivot = pivot.loc[top_rows]

            if pivot.shape[0] >= 2 and pivot.shape[1] >= 2:
                series = [{"name": str(c), "values": [float(v) for v in pivot[c]]} for c in pivot.columns]
                charts.append({
                    "column": f"{_format_business_label(numeric_cols[0])} by {_format_business_label(cat1)} & {_format_business_label(cat2)}",
                    "type": "stacked_bar",
                    "labels": [str(i) for i in pivot.index],
                    "series": series,
                    "x_label": _format_business_label(cat1),
                    "y_label": _format_business_label(numeric_cols[0]),
                })
                chart_count += 1

                if chart_count < MAX_CHARTS:
                    row_sums = pivot.sum(axis=1).replace(0, np.nan)
                    pct_pivot = pivot.div(row_sums, axis=0).fillna(0) * 100
                    series_pct = [{"name": str(c), "values": [round(float(v), 1) for v in pct_pivot[c]]} for c in pct_pivot.columns]
                    charts.append({
                        "column": f"{_format_business_label(cat1)} Composition by {_format_business_label(cat2)} (100%)",
                        "type": "stacked_bar_100",
                        "labels": [str(i) for i in pct_pivot.index],
                        "series": series_pct,
                        "x_label": _format_business_label(cat1),
                        "y_label": "Share (%)",
                    })
                    chart_count += 1
        except Exception:
            pass

    # 3) LINE + AREA + STACKED AREA — time series
    for date_col in all_date_cols:
        if chart_count >= MAX_CHARTS:
            break
        try:
            date_series = pd.to_datetime(df[date_col], errors="coerce")
            temp = df.copy()
            temp["_period"] = date_series.dt.to_period("M")
            if numeric_cols:
                metrics = numeric_cols[:3]
                grouped = temp.groupby("_period")[metrics].sum().sort_index()
                if len(grouped) >= 2:
                    primary = metrics[0]
                    charts.append({
                        "column": f"{_format_business_label(primary)} Trend ({_format_business_label(date_col)})",
                        "type": "line",
                        "labels": [str(p) for p in grouped.index],
                        "values": [float(v) for v in grouped[primary]],
                        "x_label": _format_business_label(date_col),
                        "y_label": _format_business_label(primary),
                    })
                    chart_count += 1

                    if chart_count < MAX_CHARTS:
                        charts.append({
                            "column": f"{_format_business_label(primary)} Cumulative Area",
                            "type": "area",
                            "labels": [str(p) for p in grouped.index],
                            "values": [float(v) for v in grouped[primary]],
                            "x_label": _format_business_label(date_col),
                            "y_label": _format_business_label(primary),
                        })
                        chart_count += 1

                    if len(metrics) >= 2 and chart_count < MAX_CHARTS:
                        series = [{"name": _format_business_label(m), "values": [float(v) for v in grouped[m]]} for m in metrics]
                        charts.append({
                            "column": f"Trend Comparison ({_format_business_label(date_col)})",
                            "type": "stacked_area",
                            "labels": [str(p) for p in grouped.index],
                            "series": series,
                            "x_label": _format_business_label(date_col),
                            "y_label": "Value",
                        })
                        chart_count += 1
            else:
                counts = temp["_period"].value_counts().sort_index()
                if len(counts) >= 2:
                    charts.append({
                        "column": f"Records over time ({_format_business_label(date_col)})",
                        "type": "line",
                        "labels": [str(p) for p in counts.index],
                        "values": counts.values.tolist(),
                        "x_label": _format_business_label(date_col),
                        "y_label": "Records",
                    })
                    chart_count += 1
        except Exception:
            pass

    # 4) SCATTER — correlation between the two leading numeric metrics
    if len(numeric_cols) >= 2 and chart_count < MAX_CHARTS:
        try:
            sub = df[[numeric_cols[0], numeric_cols[1]]].dropna()
            if len(sub) >= 3:
                sample = sub.head(300)
                points = [{"x": float(r[numeric_cols[0]]), "y": float(r[numeric_cols[1]])} for _, r in sample.iterrows()]
                charts.append({
                    "column": f"{_format_business_label(numeric_cols[0])} vs {_format_business_label(numeric_cols[1])}",
                    "type": "scatter",
                    "points": points,
                    "x_label": _format_business_label(numeric_cols[0]),
                    "y_label": _format_business_label(numeric_cols[1]),
                })
                chart_count += 1
        except Exception:
            pass

    # 5) PIE / DONUT — share-of-total (alternate type for visual variety)
    for i, pie_col in enumerate(category_cols):
        if chart_count >= MAX_CHARTS:
            break
        try:
            if numeric_cols:
                pie_data = df.groupby(pie_col)[numeric_cols[0]].sum().sort_values(ascending=False)
                pie_metric_label = _format_business_label(numeric_cols[0])
            else:
                pie_data = df[pie_col].value_counts()
                pie_metric_label = "Records"

            if len(pie_data) >= 2:
                if len(pie_data) > 6:
                    top = pie_data.head(5)
                    other_total = pie_data.iloc[5:].sum()
                    pie_data = pd.concat([top, pd.Series({"Other": other_total})])

                total = pie_data.sum()
                charts.append({
                    "column": f"{pie_metric_label} Share by {_format_business_label(pie_col)}",
                    "type": "pie" if i % 2 == 0 else "donut",
                    "labels": [str(v) for v in pie_data.index],
                    "values": [round(float(v) / float(total) * 100, 1) if total else 0 for v in pie_data.values],
                    "x_label": "",
                    "y_label": "",
                })
                chart_count += 1
        except Exception:
            pass

    # 6) FUNNEL — stage-style descending breakdown of the primary category
    if category_cols and chart_count < MAX_CHARTS:
        try:
            cat_col = category_cols[0]
            if numeric_cols:
                funnel_data = df.groupby(cat_col)[numeric_cols[0]].sum().sort_values(ascending=False)
                funnel_label = _format_business_label(numeric_cols[0])
            else:
                funnel_data = df[cat_col].value_counts()
                funnel_label = "Count"
            funnel_data = funnel_data.head(6)
            if len(funnel_data) >= 2:
                charts.append({
                    "column": f"{funnel_label} Funnel by {_format_business_label(cat_col)}",
                    "type": "funnel",
                    "labels": [str(v) for v in funnel_data.index],
                    "values": [float(v) for v in funnel_data.values],
                    "x_label": "",
                    "y_label": funnel_label,
                })
                chart_count += 1
        except Exception:
            pass

    # 7) RIBBON — highlight top categories with flowing comparative widths
    if category_cols and numeric_cols and chart_count < MAX_CHARTS:
        try:
            cat_col = category_cols[0]
            num_col = numeric_cols[0]
            ribbon_data = df.groupby(cat_col)[num_col].sum().sort_values(ascending=False).head(8)
            if len(ribbon_data) >= 2:
                charts.append({
                    "column": f"{_format_business_label(num_col)} Ribbon by {_format_business_label(cat_col)}",
                    "type": "ribbon",
                    "labels": [str(v) for v in ribbon_data.index],
                    "values": [float(v) for v in ribbon_data.values],
                    "x_label": _format_business_label(cat_col),
                    "y_label": _format_business_label(num_col),
                })
                chart_count += 1
        except Exception:
            pass

    # 8) WATERFALL — cumulative buildup of the primary metric across the primary category
    if category_cols and numeric_cols and chart_count < MAX_CHARTS:
        try:
            cat_col = category_cols[0]
            num_col = numeric_cols[0]
            wf_data = df.groupby(cat_col)[num_col].sum().sort_values(ascending=False).head(8)
            if len(wf_data) >= 2:
                charts.append({
                    "column": f"{_format_business_label(num_col)} Waterfall by {_format_business_label(cat_col)}",
                    "type": "waterfall",
                    "labels": [str(v) for v in wf_data.index],
                    "values": [float(v) for v in wf_data.values],
                    "x_label": _format_business_label(cat_col),
                    "y_label": _format_business_label(num_col),
                })
                chart_count += 1
        except Exception:
            pass

    # 9) LINE + CLUSTERED COLUMN — trend line + side-by-side column comparison
    if all_date_cols and len(numeric_cols) >= 2 and chart_count < MAX_CHARTS:
        try:
            date_col = all_date_cols[0]
            temp = df.copy()
            temp["_period"] = pd.to_datetime(temp[date_col], errors="coerce").dt.to_period("M")
            metrics = numeric_cols[:3]
            grouped = temp.groupby("_period")[metrics].sum().sort_index()
            if len(grouped) >= 2:
                series = []
                for m in metrics[1:]:
                    series.append({"name": _format_business_label(m), "values": [float(v) for v in grouped[m]]})
                charts.append({
                    "column": f"Line + Clustered Column: {_format_business_label(date_col)}",
                    "type": "line_and_clustered_column",
                    "labels": [str(p) for p in grouped.index],
                    "line_series": {"name": _format_business_label(metrics[0]), "values": [float(v) for v in grouped[metrics[0]]]},
                    "column_series": series,
                    "x_label": _format_business_label(date_col),
                    "y_label": "Value",
                })
                chart_count += 1
        except Exception:
            pass

    # 10) LINE + STACKED COLUMN — trend line overlay on stacked category columns
    if all_date_cols and len(numeric_cols) >= 3 and len(category_cols) >= 1 and chart_count < MAX_CHARTS:
        try:
            date_col = all_date_cols[0]
            temp = df.copy()
            temp["_period"] = pd.to_datetime(temp[date_col], errors="coerce").dt.to_period("M")
            pivot = temp.pivot_table(index="_period", columns=category_cols[0], values=numeric_cols[0], aggfunc="sum", fill_value=0)
            if pivot.shape[0] >= 2 and pivot.shape[1] >= 2:
                line_series = {"name": _format_business_label(numeric_cols[1]), "values": [float(v) for v in temp.groupby("_period")[numeric_cols[1]].sum().reindex(pivot.index, fill_value=0)]}
                charts.append({
                    "column": f"Line + Stacked Column: {_format_business_label(date_col)}",
                    "type": "line_and_stacked_column",
                    "labels": [str(p) for p in pivot.index],
                    "stack_series": [{"name": str(c), "values": [float(v) for v in pivot[c]]} for c in pivot.columns],
                    "line_series": line_series,
                    "x_label": _format_business_label(date_col),
                    "y_label": "Value",
                })
                chart_count += 1
        except Exception:
            pass

    # 11) CARD — single headline metric card for the strongest KPI
    if numeric_cols and chart_count < MAX_CHARTS:
        try:
            head_metric = numeric_cols[0]
            value = df[head_metric].sum()
            charts.append({
                "column": f"Headline Metric: {_format_business_label(head_metric)}",
                "type": "card",
                "cards": [{"label": _format_business_label(head_metric), "value": _format_metric_value(value)}],
            })
            chart_count += 1
        except Exception:
            pass

    # 12) MULTI-ROW CARD — top 3 numeric KPIs in a row
    if len(numeric_cols) >= 2 and chart_count < MAX_CHARTS:
        try:
            metrics = numeric_cols[:3]
            cards = []
            for m in metrics:
                cards.append({"label": _format_business_label(m), "value": _format_metric_value(df[m].sum())})
            charts.append({
                "column": "Top Metrics Overview",
                "type": "multi_row_card",
                "cards": cards,
            })
            chart_count += 1
        except Exception:
            pass

    # 13) DECOMPOSITION TREE — two-level category breakdown with values
    if len(category_cols) >= 2 and numeric_cols and chart_count < MAX_CHARTS:
        try:
            parent, child = category_cols[0], category_cols[1]
            tree_data = []
            parent_totals = df.groupby(parent)[numeric_cols[0]].sum().sort_values(ascending=False).head(5)
            for p_val in parent_totals.index:
                child_vals = df[df[parent] == p_val].groupby(child)[numeric_cols[0]].sum().sort_values(ascending=False).head(4)
                tree_data.append({
                    "label": str(p_val),
                    "value": float(parent_totals.loc[p_val]),
                    "children": [{"label": str(c_val), "value": float(v)} for c_val, v in child_vals.items()],
                })
            if tree_data:
                charts.append({
                    "column": f"Decomposition Tree: {_format_business_label(parent)} → {_format_business_label(child)}",
                    "type": "decomposition_tree",
                    "nodes": tree_data,
                })
                chart_count += 1
        except Exception:
            pass

    # 14) SLICER — show filterable categories and current counts
    if category_cols and chart_count < MAX_CHARTS:
        try:
            filters = []
            for col in category_cols[:3]:
                counts = full_df[col].value_counts().head(5)
                filters.append({
                    "label": _format_business_label(col),
                    "values": [{"option": str(idx), "count": int(v)} for idx, v in counts.items()]})
            charts.append({
                "column": "Slicer Preview",
                "type": "slicer",
                "filters": filters,
            })
            chart_count += 1
        except Exception:
            pass

    # 15) GAUGE — headline completeness metric (0-100 range, always meaningful)
    if chart_count < MAX_CHARTS:
        charts.append({
            "column": "Data Completeness",
            "type": "gauge",
            "gauge_value": completeness,
            "gauge_max": 100,
            "x_label": "",
            "y_label": "",
        })
        chart_count += 1

    # 9) TREEMAP — proportional share of the primary metric by primary category
    if category_cols and numeric_cols and chart_count < MAX_CHARTS:
        try:
            cat_col = category_cols[0]
            num_col = numeric_cols[0]
            tm_data = df.groupby(cat_col)[num_col].sum().sort_values(ascending=False)
            tm_data = tm_data[tm_data > 0].head(10)
            if len(tm_data) >= 2:
                nodes = [{"label": str(k), "value": float(v)} for k, v in tm_data.items()]
                charts.append({
                    "column": f"{_format_business_label(num_col)} Treemap by {_format_business_label(cat_col)}",
                    "type": "treemap",
                    "nodes": nodes,
                    "x_label": "",
                    "y_label": "",
                })
                chart_count += 1
        except Exception:
            pass

    # 10) TABLE — grouped summary table (category + all key numeric metrics)
    if category_cols and numeric_cols and chart_count < MAX_CHARTS:
        try:
            cat_col = category_cols[0]
            metrics = numeric_cols[:5]
            table_df = df.groupby(cat_col)[metrics].sum().reset_index()
            table_df = table_df.sort_values(by=metrics[0], ascending=False)
            charts.append({
                "column": f"Summary Table by {_format_business_label(cat_col)}",
                "type": "table",
                "table_columns": [_format_business_label(cat_col)] + [_format_business_label(m) for m in metrics],
                "rows": table_df.values.tolist(),
                "x_label": "",
                "y_label": "",
            })
            chart_count += 1
        except Exception:
            pass

    # 11) MATRIX — 2-dimension pivot table (if 2+ categorical columns exist)
    if len(category_cols) >= 2 and numeric_cols and chart_count < MAX_CHARTS:
        try:
            cat1, cat2 = category_cols[0], category_cols[1]
            pivot = df.pivot_table(index=cat1, columns=cat2, values=numeric_cols[0], aggfunc="sum", fill_value=0)
            if pivot.shape[1] > 6:
                top_cols = pivot.sum().sort_values(ascending=False).head(6).index
                pivot = pivot[top_cols]
            if pivot.shape[0] > 10:
                top_rows = pivot.sum(axis=1).sort_values(ascending=False).head(10).index
                pivot = pivot.loc[top_rows]
            if pivot.shape[0] >= 2 and pivot.shape[1] >= 2:
                matrix_rows = [[str(idx)] + [float(v) for v in row] for idx, row in pivot.iterrows()]
                charts.append({
                    "column": f"{_format_business_label(numeric_cols[0])} Matrix: {_format_business_label(cat1)} × {_format_business_label(cat2)}",
                    "type": "matrix",
                    "table_columns": [_format_business_label(cat1)] + [str(c) for c in pivot.columns],
                    "rows": matrix_rows,
                    "x_label": "",
                    "y_label": "",
                })
                chart_count += 1
        except Exception:
            pass

    # 12) Fallback — numeric distribution histogram (only if nothing else could be generated)
    if not category_cols and not all_date_cols:
        for col in numeric_cols:
            if chart_count >= MAX_CHARTS:
                break
            col_data = df[col].dropna()
            if col_data.empty:
                continue
            try:
                counts, bin_edges = np.histogram(col_data, bins=10)
                labels = [f"{bin_edges[i]:.1f}-{bin_edges[i+1]:.1f}" for i in range(len(bin_edges) - 1)]
                charts.append({
                    "column": f"{_format_business_label(col)} distribution",
                    "type": "bar",
                    "labels": labels,
                    "values": counts.tolist(),
                    "x_label": _format_business_label(col),
                    "y_label": "Frequency",
                })
                chart_count += 1
            except Exception:
                pass

    # ---- Chart diversity cap: same type ko zyada repeat nahi hone dete ----
    # (e.g. agar 6 category columns hain to "bar" type 6 baar generate ho sakta
    # tha — max 3 per type rakhte hain taake dashboard visually diverse rahe)
    MAX_PER_TYPE = 3
    type_counts = {}
    diverse_charts = []
    for ch in charts:
        t = ch["type"]
        type_counts[t] = type_counts.get(t, 0) + 1
        if type_counts[t] <= MAX_PER_TYPE:
            diverse_charts.append(ch)
    charts = diverse_charts

    # ---- Slicer metadata: which columns + values the frontend can filter by ----
    # Always built from full_df (unfiltered) so dropdown options stay complete.
    filters_available = {}
    for col in category_cols:
        try:
            filters_available[col] = sorted(full_df[col].dropna().astype(str).unique().tolist())[:50]
        except Exception:
            pass

    # ---- Verified facts (Python-calculated, ground truth for AI to reference) ----
    # Isse "AI Insight double-validation" ka pehla step milta hai: AI ko
    # hallucinate karne ki zaroorat nahi, ye facts already sahi calculated hain.
    verified_facts = {}
    calculation_correct = True
    try:
        if category_cols and numeric_cols:
            primary_cat, primary_num = category_cols[0], numeric_cols[0]
            grouped_check = df.groupby(primary_cat)[primary_num].sum()
            if not grouped_check.empty:
                top_key = grouped_check.idxmax()
                verified_facts["top_category"] = {
                    "column": _format_business_label(primary_cat),
                    "value": str(top_key),
                    "metric": _format_business_label(primary_num),
                    "amount": float(grouped_check.max()),
                }
                # ---- Result sanity check: parts ka sum, whole ke sum ke barabar hona chahiye ----
                whole_sum = float(df[primary_num].dropna().sum())
                parts_sum = float(grouped_check.sum())
                calculation_correct = abs(whole_sum - parts_sum) < max(1.0, abs(whole_sum) * 0.001)
    except Exception:
        calculation_correct = True  # validation khud fail na ho jaye, benefit of doubt

    trust_score = {
        "data_valid": len(df) > 0 and len(df.columns) > 0,
        "calculation_correct": calculation_correct,
        "score": sum([len(df) > 0, len(df.columns) > 0, calculation_correct]),
        "max_score": 3,
    }

    summary_stats = {
        "total_rows": len(df),
        "total_columns": len(df.columns),
        "numeric_columns": len(numeric_cols),
        "category_columns": len(category_cols),
        "date_columns": len(all_date_cols),
        "missing_count": missing_cells,
        "completeness_pct": completeness,
    }

    return {
        "summary": summary_stats,
        "kpis": kpis,
        "charts": charts,
        "filters_available": filters_available,
        "insights": insights,
        "recommendations": recommendations,
        "verified_facts": verified_facts,
        "trust_score": trust_score,
    }

TOOL_REGISTRY = {
    "drop_duplicates": drop_duplicates,
    "fill_missing": fill_missing,
    "convert_dtype": convert_dtype,
    "strip_whitespace_and_normalize_case": strip_whitespace_and_normalize_case,
    "remove_outliers_iqr": remove_outliers_iqr,
    "rename_columns": rename_columns,
    "drop_columns": drop_columns,
}

# JSON Schemas — ye Claude ke tool-use API ko batate hain kaunse tools
# available hain aur unke parameters kya hain.
TOOL_SCHEMAS = [
    {
        "name": "drop_duplicates",
        "description": "Poore dataset se duplicate rows remove karta hai.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "fill_missing",
        "description": "Ek column ke missing/null values ko strategy ke mutabiq fill karta hai.",
        "input_schema": {
            "type": "object",
            "properties": {
                "column": {"type": "string"},
                "strategy": {
                    "type": "string",
                    "enum": ["mean", "median", "mode", "zero", "drop_rows"],
                },
            },
            "required": ["column", "strategy"],
        },
    },
    {
        "name": "convert_dtype",
        "description": "Column ka data type convert karta hai.",
        "input_schema": {
            "type": "object",
            "properties": {
                "column": {"type": "string"},
                "target_type": {
                    "type": "string",
                    "enum": ["int", "float", "str", "datetime", "category"],
                },
            },
            "required": ["column", "target_type"],
        },
    },
    {
        "name": "strip_whitespace_and_normalize_case",
        "description": "Text column se extra spaces hataata hai aur case normalize karta hai.",
        "input_schema": {
            "type": "object",
            "properties": {
                "column": {"type": "string"},
                "case": {"type": "string", "enum": ["lower", "upper", "title", "none"]},
            },
            "required": ["column"],
        },
    },
    {
        "name": "remove_outliers_iqr",
        "description": "IQR method use karke numeric column ke outliers remove karta hai.",
        "input_schema": {
            "type": "object",
            "properties": {"column": {"type": "string"}},
            "required": ["column"],
        },
    },
    {
        "name": "rename_columns",
        "description": "Columns ke naam rename karta hai. mapping = {'old_name': 'new_name'}.",
        "input_schema": {
            "type": "object",
            "properties": {"mapping": {"type": "object"}},
            "required": ["mapping"],
        },
    },
    {
        "name": "drop_columns",
        "description": "Diye gaye columns ko dataset se hata deta hai.",
        "input_schema": {
            "type": "object",
            "properties": {"columns": {"type": "array", "items": {"type": "string"}}},
            "required": ["columns"],
        },
    },
]
