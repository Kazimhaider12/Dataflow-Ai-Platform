"""
auth.py
--------
Simple built-in auth — koi external service (Supabase etc.) ki zaroorat
nahi, taake zero-cost aur zero-setup rahe. Password PBKDF2 (Python
built-in, no extra dependency) se hash hota hai, login pe ek random
token milta hai jo Authorization header mein bhejna hota hai.

Agar baad mein Supabase Auth pe switch karna ho, sirf ye file replace
karni hai — baaki app isi `get_current_user` dependency pe depend karta
hai, to migration asaan rahega.
"""

import hashlib
import hmac
import os
import secrets
from fastapi import Header, HTTPException
import db

PBKDF2_ITERATIONS = 200_000


def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), PBKDF2_ITERATIONS)
    return f"{salt}${dk.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        salt, hash_hex = stored_hash.split("$")
    except ValueError:
        return False
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), PBKDF2_ITERATIONS)
    return hmac.compare_digest(dk.hex(), hash_hex)


def get_current_user(authorization: str = Header(None)) -> str:
    """
    FastAPI dependency — Authorization header se "Bearer <token>" nikalta
    hai, token verify karta hai, aur user_id return karta hai.
    Protected endpoints mein: `user_id: str = Depends(get_current_user)`
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Login required. Authorization header missing.")

    token = authorization.split(" ", 1)[1]
    user_id = db.get_user_id_by_token(token)
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid or expired token. Please login again.")

    return user_id
